from platoon_v2v.speed_resolution import signed_speed_from_telemetry


def test_throttle_sign_restores_reverse_encoder_speed():
    assert signed_speed_from_telemetry(0.31, -0.4) == -0.31


def test_throttle_fallback_provides_signed_low_speed_command():
    assert signed_speed_from_telemetry(0.0, -0.2) == -0.1


def test_neutral_throttle_keeps_measured_speed():
    assert signed_speed_from_telemetry(0.12, 0.0) == 0.12


def test_rc_pwm_fallback_provides_reverse_when_normalized_throttle_is_zero():
    assert signed_speed_from_telemetry(0.0, 0.0, 1300) == -0.25


def test_rc_pwm_deadband_keeps_trimmed_neutral_at_zero():
    assert signed_speed_from_telemetry(0.0, 0.0, 1460) == 0.0
